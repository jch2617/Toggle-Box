// document.querySelector('#remove').addEventListener('click', () =>{
//     // 
//     $element = document.querySelector('#remove-me');
//     $element.remove();
// })
// document.querySelector('#add').addEventListener('click', () =>{
//     const $element = document.createElement('li');
//     $element.innerHTML = 'Remove Me again.';
//     const $button = document.createElement('button');
//     $button.innerHTML = 'X';
//     $element.appendChild($button);
//     $button.addEventListener('click', event => {
//         $element.remove();
//     });
//     document.querySelector('ul').appendChild($element)
// })
// const lis = document.querySelectorAll('li');
// for(const li of lis) {
//     li.addEventListener('dblclick', event => {
//         $elementToDelete = event.target;
//         $elementToDelete.remove();
//     });
// }

function toggleColor() {
    document.body.style.backgroundColor= "lightcoral";
}


function addBox() {
    let addme = document.createElement("div");
    addme.classList.add("box");
    addme.textContent = "I'm a box!";
    addme.style.width = "100px";
    addme.style.height = "100px";
    addme.style.border = "5px solid black";
    document.body.appendChild(addme);
    addme.value++;
 }

 let newbutton = document.getElementById("add-box");
 newbutton.addEventListener('click', addBox);